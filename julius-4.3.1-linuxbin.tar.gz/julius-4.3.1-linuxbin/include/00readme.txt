--------------
These are headers of Juliuslib.

They are set up with default configuration (i.e. no argument for
configure script).  If you want to enable other setting,
ex. decoder-based VAD or GMM-based VAD, you should compile them
and bring the headers from source code by your own.
